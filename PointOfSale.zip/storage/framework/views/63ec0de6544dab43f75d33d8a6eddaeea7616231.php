<?php $__env->startSection('title', 'Manage Sales'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Manage Sales</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Sales</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12 ">
            <!-- Custom tabs (Charts with tabs)-->
            <div class="card">
              <div class="card-header">
               <h4>Sales List</h4>
                  <a class="btn btn-success btn-sm float-right " href="<?php echo e(route('admin.sale.create')); ?>">
                      <i class="fa fa-plus-circle"> Create Sale </i>
                  </a>
              </div><!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>SL No</th>
                        <th>Sale No</th>
                        <th> No of Products</th>
                        <th> Total Amount </th>
                        <th> Customer Name </th>
                        <th> Purchase Created </th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $last_week_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key +1); ?></td>
                        <td><?php echo e($sale->invoice_no); ?></td>
                        <td><?php echo e($sale->count()); ?></td>
                        <td><?php echo e($sale->total); ?></td>
                        <td><?php echo e($sale->customer->name); ?></td>
                        <td><?php echo e($sale->created_at->format('d-M-Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.sale.show',$sale->id)); ?>" class="btn btn-primary btn-sm" title="View Details">
                                <i class="fa fa-eye"></i>
                            </a>
                            <button type="button"  class="btn btn-danger waves-effect btn-sm" onclick="deletedata(<?php echo e($sale->id); ?>)">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                            <form  id="delete-data-<?php echo e($sale->id); ?>" action="<?php echo e(route('admin.sale.destroy',$sale->id)); ?>"
                                   method="post" style="display:none;"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- /.card -->
          </section>
          <!-- /.Left col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PointOfSale\resources\views/pdf/lastWeekSaleList.blade.php ENDPATH**/ ?>