<?php $__env->startSection('title', 'Manage Product'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Manage Product</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Product</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12 ">
            <!-- Custom tabs (Charts with tabs)-->
            <div class="card">
              <div class="card-header">
               <h4>Add Product</h4>
                  <a class="btn btn-success btn-sm float-right " href="<?php echo e(route('admin.product.index')); ?>">
                      <i class="fa fa-list"> Product List</i>
                  </a>
              </div><!-- /.card-header -->
              <div class="card-body">
                <form action="<?php echo e(route('admin.product.store')); ?>" method="post" id="createProduct" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">

                        <div class="form-group col-md-4">
                            <label>Supplier Name</label>
                            <select name="supplier_id" class="form-control select2" style="width: 100%;">
                                <option selected="selected">Select Supplier</option>
                                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Category Name</label>
                            <select name="category_id" class="form-control select2" style="width: 100%;">
                                <option selected="selected">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label>Unit Name</label>
                            <select name="unit_id" class="form-control select2" style="width: 100%;">
                                <option selected="selected">Select Unit</option>
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label class="text-center"> Product Name</label>
                            <input type="text" name="name" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="text-center"> Product Image</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="text-center"> Product Code</label>
                            <input type="text" name="product_code" class="form-control">
                        </div>

                        <div class="form-group col-md-4 offset-5">
                            <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-dark">Back</a>
                            <button type="submit" class="btn btn-success">Create</button>
                        </div>

                    </div>

                </form>
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- /.card -->
          </section>
          <!-- /.Left col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(function () {

            $('#createProduct').validate({
                rules: {
                    supplier_id: {
                        required: true,
                    },
                    category_id: {
                        required: true,
                    },
                    unit_id: {
                        required: true,
                    },
                    name: {
                        required: true,
                    },

                },
                messages: {

                    name: {
                        required: "Please enter a name"
                    },
                    supplier_id:{
                        required: "Please choose a supplier",
                    },
                    category_id:{
                        required: "Please choose a category",
                    },
                    unit_id:{
                        required: "Please choose a unit",
                    },

                },
                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\InventoryManagement\resources\views/admin/product/createProduct.blade.php ENDPATH**/ ?>