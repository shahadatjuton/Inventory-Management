<?php
$prefix = Request::route()->getPrefix();
$route = Route::current()->getName();
?>

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <span class="brand-text font-weight-light">Point Of Sale</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('storage/profile/'.Auth::user()->image)); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/user')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/user')?'active':''); ?>">
                    <i class="nav-icon fas fa-user"></i>
                    <p>
                        Manage User
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.user.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.user.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>User List</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.user.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.user.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create User</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e(($prefix == '/profile')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == '/profile')?'active':''); ?>">
                    <i class="nav-icon far fa-user-circle"></i>
                    <p>
                        Manage Profile
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('profile.index')); ?>" class="nav-link
                            <?php echo e(($route == 'profile.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Profile</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('password.change')); ?>" class="nav-link
                            <?php echo e(($route == 'password.change')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Change Password</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/supplier')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/supplier')?'active':''); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Manage Supplier
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.supplier.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.supplier.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Supplier</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.supplier.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.supplier.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create Supplier</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/customer')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/customer')?'active':''); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Manage Customer
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.customer.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.customer.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Customer</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.customer.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.customer.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create Customer</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/unit')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/unit')?'active':''); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Manage Unit
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.unit.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.unit.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Unit</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.unit.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.unit.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create Unit</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/category')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/category')?'active':''); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Manage Category
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.category.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.category.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Category</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.category.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.category.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create Category</p>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/product')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/product')?'active':''); ?>">
                    <i class="nav-icon fas fa-shopping-basket"></i>
                    <p>
                        Manage Product
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.product.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.product.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Product</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.product.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.product.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create Product</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e(($prefix == 'admin/purchase')?'menu-open':''); ?>">
                <a href="#" class="nav-link <?php echo e(($prefix == 'admin/purchase')?'active':''); ?>">
                    <i class="nav-item fas fa-shopping-cart"></i>
                    <p>
                        Manage Purchase
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.purchase.index')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.purchase.index')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>View Purchase</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.purchase.create')); ?>" class="nav-link
                            <?php echo e(($route == 'admin.purchase.create')? 'active': ''); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Create Purchase</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview ">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH C:\xampp\htdocs\InventoryManagement\resources\views/layouts/backend/partial/sidebar.blade.php ENDPATH**/ ?>