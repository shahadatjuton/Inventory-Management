<?php $__env->startSection('title', 'Manage Report'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->

    <link href="<?php echo e(asset('assets/backend/css/invoice.css')); ?>" rel="stylesheet">


    <!------ Include the above in your HEAD tag ---------->

    <!--Author      : @arboshiki-->
    <div id="invoice">

        <div class="toolbar hidden-print">
            <div class="text-right">
                <button id="printInvoice" class="btn btn-info"><i class="fa fa-print"></i> Print</button>
                <button class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Export as PDF</button>
            </div>
            <hr>
        </div>
        <?php if($sales->count() < 1 ): ?>
        <div class="text-warning">
            <h3 class="text-center"> No sales found from <?php echo e($start_date); ?> to <?php echo e($end_date); ?></h3>
        </div>
    <?php endif; ?>
        <div class="invoice overflow-auto">
            <div style="min-width: 600px">
                <header>
                    <div class="row">
                        <div class="col">
                            <h4>POS</h4>
                        </div>
                        <div class="col company-details">
                            <h2 class="name">
                                <a target="_blank" href="https://lobianijs.com">
                                    POS
                                </a>
                            </h2>
                            <div>18-Kemal Ataturk, Banani , Dhaka.</div>
                            <div>(123) 456-789</div>
                            <div>company@example.com</div>
                        </div>
                    </div>
                </header>
                <main>
                    <div class="row contacts">
                        <div class="col invoice-details">
                            <h1 class="invoice-id text-center"><?php echo e($start_date); ?> To <?php echo e($end_date); ?></h1>
                        </div>
                    </div>
                    <table border="0" cellspacing="0" cellpadding="0">
                        <thead>
                        <tr>
                            <th>Serial Number</th>
                            <th>Invoice Number</th>
                            <th>Created By</th>
                            <th>Created Date</th>
                            <th>TOTAL</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key +1); ?></td>
                                <td><?php echo e($sale->invoice_no); ?></td>
                                <td><?php echo e($sale->user->name); ?></td>
                                <td><?php echo e($sale->created_at->format('d-M-Y')); ?></td>
                                <td><?php echo e($sale->total); ?> <span>TAKA</span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2">GRAND TOTAL</td>
                            <td><?php echo e($sales->sum('total')); ?> TAKA </td>
                        </tr>
                        </tfoot>
                    </table>
                </main>


                <div class="float-right">
                    <div class="signature-right">
                        ....................................................
                        <h4>Owner Signature</h4>
                    </div>
                </div>
            </div>
            <!--DO NOT DELETE THIS div. IT is responsible for showing footer always at the bottom-->
            <div></div>
        </div>
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PointOfSale\resources\views/pdf/dailySaleInvoice.blade.php ENDPATH**/ ?>